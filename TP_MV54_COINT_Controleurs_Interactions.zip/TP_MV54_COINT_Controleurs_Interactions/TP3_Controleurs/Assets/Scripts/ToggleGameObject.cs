using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToggleGameObject : MonoBehaviour
{
    public GameObject zoneSpawner;
    public GameObject ballSpawner;
    public GameObject gameObjectToToggle;

    public void Toggle()
    {
        if (gameObjectToToggle)
        {
            gameObjectToToggle.SetActive(!gameObjectToToggle.activeSelf);
        }
        if (ballSpawner)
        {
            Instantiate(ballSpawner, zoneSpawner.transform.position, Quaternion.identity);
        }
    }
}
