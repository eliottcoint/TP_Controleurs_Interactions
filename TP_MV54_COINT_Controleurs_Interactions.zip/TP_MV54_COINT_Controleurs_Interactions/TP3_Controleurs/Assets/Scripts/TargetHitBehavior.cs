using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetHitBehavior : MonoBehaviour
{
    public Light sceneLight;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Balle"))
        {
            if (sceneLight.enabled == false)
            {
                sceneLight.enabled = true;
            }
            else
            {
                // D�sactive la lumi�re lorsque la cible est touch�e
                sceneLight.enabled = false;
            }
        }
    }
}