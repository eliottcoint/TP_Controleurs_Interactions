using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCibleBehavior : MonoBehaviour
{
    private void Update()
    {
        transform.position = new Vector3(transform.position.x, transform.position.y, Mathf.PingPong(Time.time, 8) - 4);
    }
}
