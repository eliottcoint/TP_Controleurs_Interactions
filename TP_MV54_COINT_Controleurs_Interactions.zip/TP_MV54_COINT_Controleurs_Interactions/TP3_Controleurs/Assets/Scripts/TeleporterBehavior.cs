using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class TeleporterBehavior : MonoBehaviour
{
    private bool canTeleport = false;
    private bool pointerVisible = false;
    private Vector3 destinationPoint;
    private LineRenderer lineRenderer;
    public int maxDistance = 5;
    public string floorTag;
    public string zonetirTag;
    public GameObject player;
    public Material PointerNokMaterial;
    public Material PointerOkMaterial;
    public Material PointerZoneTirMaterial;

    // Si le joueur se t�l�porte dans une zone de tir
    public bool isZoneTir = true;

    // R�f�rence au script de score
    public ScoreBehavior scoreScript;

    // Start is called before the first frame update
    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        HidePointer();
    }

    void HidePointer()
    {
        if (lineRenderer)
        {
            lineRenderer.enabled = false;
        }
        pointerVisible = false;
    }

    void ShowPointer()
    {
        if (lineRenderer)
        {
            lineRenderer.enabled = true;
        }
        pointerVisible = true;
    }

    void Teleport()
    {
        if (player)
        {
            player.transform.position = destinationPoint;
        }
    }

    public void OnTeleportAction(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            ShowPointer();
        }
        if (context.canceled)
        {
            if (canTeleport)
            {
                // V�rifie si le joueur se t�l�porte dans une zone de tir
                if (scoreScript != null && isZoneTir)
                {
                    scoreScript.SetPointMultiplier(3); // D�finit le multiplicateur de points sur 3
                }
                else
                {
                    scoreScript.SetPointMultiplier(1); // Remet le multiplicateur de points � 1
                }

                //ecrit le setpointmultiplier dans la console
                Debug.Log("SetPointMultiplier: " + scoreScript.GetPointMultiplier());

                Teleport();
            }
            HidePointer();
        }
    }

    private void FixedUpdate()
    {
        if (pointerVisible)
        {
            lineRenderer.SetPosition(0, transform.position);
            RaycastHit hit;
            if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit, maxDistance))
            {
                if (hit.collider.gameObject.CompareTag(floorTag))
                {
                    canTeleport = true;
                    destinationPoint = hit.point;
                    lineRenderer.material = PointerOkMaterial;
                }
                else if (hit.collider.gameObject.CompareTag(zonetirTag))
                {
                    canTeleport = true;
                    isZoneTir = true;
                    destinationPoint = hit.collider.gameObject.transform.position;
                    lineRenderer.material = PointerZoneTirMaterial;
                }
                else
                {
                    isZoneTir = false;
                    canTeleport = false;
                    lineRenderer.material = PointerNokMaterial;
                }

                lineRenderer.SetPosition(1, transform.position + transform.forward * hit.distance);
            }
            else
            {
                lineRenderer.material = PointerNokMaterial;
                lineRenderer.SetPosition(1, transform.position + transform.forward * maxDistance);
            }
        }
    }
}
