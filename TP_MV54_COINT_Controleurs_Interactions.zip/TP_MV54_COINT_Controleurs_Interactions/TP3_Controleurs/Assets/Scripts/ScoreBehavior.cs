using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ScoreBehavior : MonoBehaviour
{
    private TextMeshPro scoreText;
    private int pointMultiplier = 1; // Multiplicateur de points par d�faut

    private void Start()
    {
        // Recherchez le TextMeshPro avec le tag "Score" et stockez une r�f�rence
        scoreText = GameObject.FindGameObjectWithTag("Score").GetComponent<TextMeshPro>();
    }

    // Multiplicateur de points
    public void SetPointMultiplier(int multiplier)
    {
        pointMultiplier = multiplier;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("ZonePoint") || other.CompareTag("ZoneCible"))
        {
            if (other.CompareTag("ZoneCible"))
            {
                // Incr�mente le multiplicateur de points
                pointMultiplier = 5;
            }

            // Incr�mente le score en fonction du multiplicateur de points
            int currentScore = int.Parse(scoreText.text.Replace("Score : ", ""));
            currentScore += 1 * pointMultiplier; // Ajoute 1 point multipli� par le multiplicateur
            scoreText.text = "Score : " + currentScore.ToString();
        }
    }

    //GetPointMultiplier
    public int GetPointMultiplier()
    {
        return pointMultiplier;
    }
}
