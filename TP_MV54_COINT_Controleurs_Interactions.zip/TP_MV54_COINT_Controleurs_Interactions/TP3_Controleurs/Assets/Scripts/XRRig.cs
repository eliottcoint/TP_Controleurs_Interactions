using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class XRRig : MonoBehaviour
{
    public Animator rightAnimator;
    public GameObject rightThumbstick;
    public Animator rightHandAnimator;

    public Animator leftAnimator;
    public GameObject leftThumbstick;
    public Animator leftHandAnimator;

    private Vector3 offset = new Vector3(7.324f, 43.706f, -96.98f);

    // Right Controller : Button A //
    public void OnAPressed(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            Debug.Log("A Pressed");
            if (rightAnimator)
            {
                rightAnimator.SetBool("APressed", true);
            }
        }
        if (context.canceled)
        {
            Debug.Log("A Released");
            if (rightAnimator)
            {
                rightAnimator.SetBool("APressed", false);
            }
        }
    }

    // Right Controller : Button B //
    public void OnBPressed(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            Debug.Log("B Pressed");
            if (rightAnimator)
            {
                rightAnimator.SetBool("BPressed", true);
            }
        }
        if (context.canceled)
        {
            Debug.Log("B Released");
            if (rightAnimator)
            {
                rightAnimator.SetBool("BPressed", false);
            }
        }
    }

    // Right Controller : Trigger //
    public void OnRTriggerAxis(InputAction.CallbackContext context)
    {
        if (rightAnimator)
        {
            rightAnimator.SetFloat("RightTrigger", context.ReadValue<float>());
        }
    }

    // Right Controller : Joystick //
    public void OnRThumbstickAxis(InputAction.CallbackContext context)
    {
        if (rightThumbstick)
        {
            Vector2 thumbstickValue = context.ReadValue<Vector2>();
            rightThumbstick.transform.localEulerAngles = new Vector3(thumbstickValue.y, 0, -
           thumbstickValue.x) * 15f;
        }
    }

    // Right Controller : Trigger Touch //
    public void OnRTriggerTouch(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (rightHandAnimator)
            {
                rightHandAnimator.SetBool("Point", false);
            }
        }
        if (context.canceled)
        {
            if (rightHandAnimator)
            {
                rightHandAnimator.SetBool("Point", true);
            }
        }
    }

    // Right Controller : Grip Button //
    public void OnRGripAxis(InputAction.CallbackContext context)
    {
        if (rightHandAnimator)
        {
            rightHandAnimator.SetFloat("Close", context.ReadValue<float>());
        }
    }

    // Left Joystick : X Button //
    public void OnXPressed(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            Debug.Log("X Pressed");
            if (leftAnimator)
            {
                leftAnimator.SetBool("XPressed", true);
            }
        }
        if (context.canceled)
        {
            Debug.Log("X Released");
            if (leftAnimator)
            {
                leftAnimator.SetBool("XPressed", false);
            }
        }
    }

    // Left Joystick : Y Button //
    public void OnYPressed(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            Debug.Log("Y Pressed");
            if (leftAnimator)
            {
                leftAnimator.SetBool("YPressed", true);
            }
        }
        if (context.canceled)
        {
            Debug.Log("Y Released");
            if (leftAnimator)
            {
                leftAnimator.SetBool("YPressed", false);
            }
        }
    }

    // Left Joystick : Trigger //
    public void OnLTriggerAxis(InputAction.CallbackContext context)
    {
        if (leftAnimator)
        {
            leftAnimator.SetFloat("LeftTrigger", context.ReadValue<float>());
        }
    }

    // Left Joystick : Joystick //
    public void OnLThumbstickAxis(InputAction.CallbackContext context)
    {
        if (leftThumbstick)
        {
            Vector2 thumbstickValue = context.ReadValue<Vector2>();
            leftThumbstick.transform.localEulerAngles = new Vector3(thumbstickValue.y, 0, -
           thumbstickValue.x) * 15f + offset;
        }
    }

    // Left Controller : Trigger Touch //
    public void OnLTriggerTouch(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (leftHandAnimator)
            {
                leftHandAnimator.SetBool("Point", false);
            }
        }
        if (context.canceled)
        {
            if (leftHandAnimator)
            {
                leftHandAnimator.SetBool("Point", true);
            }
        }
    }

    // Left Controller : Grip Button //
    public void OnLGripAxis(InputAction.CallbackContext context)
    {
        if (leftHandAnimator)
        {
            leftHandAnimator.SetFloat("Close", context.ReadValue<float>());
        }
    }
}
